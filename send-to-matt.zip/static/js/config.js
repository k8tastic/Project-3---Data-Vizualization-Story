// API key
const API_KEY = "pk.eyJ1Ijoic2FuZ2Zyb2lkOTkiLCJhIjoiY2p0bTVkYXY2MGRucDRhbzJvaTc3Z3FyOSJ9.6wnhIgUwHSI6cXlGi_2d3Q";
