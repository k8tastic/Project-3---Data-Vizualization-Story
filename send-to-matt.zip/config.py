zillow_api_key = 'X1-ZWz1gx8me6fbbf_a57uf'
weather_api_key = '4e6d6a5c288a083324544f3217c6ebfd'
twitter_api_key = 'pZVfzh1pp5qrtWoo1ZboKTL7p'
twitter_apisecret_key = "UWpJhEZJnfcwiHUbGa9oUx5nolQh5oOkH7yvlvZfv8upq8oMov"
nytimes_api_key = '2a5bc978915f4b73a8a2f0c76ed8dc87'
worldbank_api_key = ''
gkey = 'AIzaSyDJVHUu96plcDqAI2Bt64siywZOs7pWZ6w'
census_api_key = '85ac64b6b5a9c0901b00329d1ef41f0c53ccfc98'

# AWS Database Info
remote_db_endpoint = 'foreclosurefools.cp6br7grzbbr.us-east-2.rds.amazonaws.com'
remote_db_port = '3306'
remote_dbname = 'foreclosurefools'
remote_dbuser = 'root'
remote_dbpwd = 'maryland9'


# Salesforce 
# sf_grant_type = 
sf_client_id = 'andrewjgrimaldi@aol.com' # Consumer Key
sf_client_secret = '' # Consumer Secret
sf_username = '' # The email you use to login
sf_password = '' # Concat your password and your security token
sf_endpoint = 'https://login.salesforce.com/services/oauth2/token'

#quandl
quandl_api_key = 'o4Py6ix7jnaNT2E3jjSW'